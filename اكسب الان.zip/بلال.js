function showShare() {
    const message = document.getElementById("message");
    message.innerHTML = `🎉 مبروك كسبت 10 جيجا من أورنج!<br><br>
    📢 <b>ابعت الرابط إلى 10 من أصدقائك حتّى توصلك الهدية</b><br><br>
    
    <a href="https://api.whatsapp.com/send?text=مبروك+كسبت+10جيجا+من+Orange+🎁+سجّل+الآن:+https://eksebma3orange.com" target="_blank">🔗 إرسال على واتساب</a><br>
    
    <a href="https://www.facebook.com/sharer/sharer.php?u=https://eksebma3orange.com" target="_blank">🔗 إرسال على ماسنجر</a><br><br>
    
    <button onclick="copyLink()">📋 انسخ الرابط</button>`;
}